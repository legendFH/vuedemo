<template>
  <el-main>
    <el-alert
      :closable="false"
      :title="'当前登陆时间：'+loginDate"
      type="success"/>
    {{ res }}
  </el-main>
</template>

<script>
export default {
  name: 'Dashboard',
  data() {
    return {
      loginDate: new Date(),
      res: ''
    }
  },
  mounted() {
    this.axios.get('/Exams').then(res => {
      this.res = res.data
    })
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .dashboard {
    &-container {
      margin: 30px;
    }

    &-text {
      font-size: 30px;
      line-height: 46px;
    }
  }
</style>
