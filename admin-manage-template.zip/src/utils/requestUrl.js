const requestURL = 'http://localhost:55160/api/'
export { requestURL }
