
const user = {
  state: {

  },

  mutations: {

  },

  actions: {

  }
}

export default user
