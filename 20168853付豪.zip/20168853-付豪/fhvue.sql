/*
 Navicat Premium Data Transfer

 Source Server         : fh1
 Source Server Type    : MySQL
 Source Server Version : 50641
 Source Host           : 101.132.115.92:3306
 Source Schema         : fhvue

 Target Server Type    : MySQL
 Target Server Version : 50641
 File Encoding         : 65001

 Date: 17/06/2019 15:41:38
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for classinfo
-- ----------------------------
DROP TABLE IF EXISTS `classinfo`;
CREATE TABLE `classinfo`  (
  `classid` int(20) NOT NULL AUTO_INCREMENT,
  `stuid` int(255) NULL DEFAULT NULL,
  `classname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `classdate` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `classplace` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `teacherid` int(255) NULL DEFAULT NULL,
  PRIMARY KEY (`classid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of classinfo
-- ----------------------------
INSERT INTO `classinfo` VALUES (1, 1001, '高等数学', '周四（5，6节）', '1213', 1001);
INSERT INTO `classinfo` VALUES (2, 1002, '大学英语', '周二（1，2）节', '1112', 1003);
INSERT INTO `classinfo` VALUES (4, 1009, '大学语文', '周一全天', '2103', 1009);
INSERT INTO `classinfo` VALUES (5, 1001, '线性代数', '周二', '1314', 1001);
INSERT INTO `classinfo` VALUES (6, 1001, '大学语文', '周一', '1312', 1001);
INSERT INTO `classinfo` VALUES (7, 1001, '线性代数', '周三（1，2节）', '1312', 1001);
INSERT INTO `classinfo` VALUES (8, 1001, '机器学习', '周六', '2313', 1003);

-- ----------------------------
-- Table structure for courseinfo
-- ----------------------------
DROP TABLE IF EXISTS `courseinfo`;
CREATE TABLE `courseinfo`  (
  `courseid` int(20) NOT NULL AUTO_INCREMENT,
  `coursename` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `coursekind` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `coursetype` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `credit` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`courseid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1005 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of courseinfo
-- ----------------------------
INSERT INTO `courseinfo` VALUES (1001, '高等数学', '理科', '必修', '4');
INSERT INTO `courseinfo` VALUES (1002, '大学英语', '文科', '必修', '5');
INSERT INTO `courseinfo` VALUES (1003, '大学语文', '文科', '选修', '4');

-- ----------------------------
-- Table structure for gradeinfo
-- ----------------------------
DROP TABLE IF EXISTS `gradeinfo`;
CREATE TABLE `gradeinfo`  (
  `gradeid` int(20) NOT NULL AUTO_INCREMENT,
  `stuid` int(20) NULL DEFAULT NULL,
  `stuname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `coursename` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `credit` int(10) NULL DEFAULT NULL,
  `grade` int(10) NULL DEFAULT NULL,
  `teacherid` int(255) NULL DEFAULT NULL,
  PRIMARY KEY (`gradeid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of gradeinfo
-- ----------------------------
INSERT INTO `gradeinfo` VALUES (1, 1001, '阿卡丽', '高等数学', 4, 80, 1001);
INSERT INTO `gradeinfo` VALUES (3, 1002, '伊泽瑞尔', '大学英语', 4, 68, 1001);
INSERT INTO `gradeinfo` VALUES (4, 1001, '阿卡丽', '线性代数', 4, 52, 1001);
INSERT INTO `gradeinfo` VALUES (5, 1001, '阿卡丽', 'JAVAEE', 3, 0, 1001);
INSERT INTO `gradeinfo` VALUES (6, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `gradeinfo` VALUES (7, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `gradeinfo` VALUES (8, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `gradeinfo` VALUES (9, NULL, NULL, NULL, NULL, NULL, NULL);

-- ----------------------------
-- Table structure for major
-- ----------------------------
DROP TABLE IF EXISTS `major`;
CREATE TABLE `major`  (
  `majorid` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `majorname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`majorid`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for managerinfo
-- ----------------------------
DROP TABLE IF EXISTS `managerinfo`;
CREATE TABLE `managerinfo`  (
  `managerid` int(20) NOT NULL AUTO_INCREMENT,
  `manpassword` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `managername` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `sex` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `manageridcard` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `birthday` date NULL DEFAULT NULL,
  `mandepartname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `manposition` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `mantel` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `manaddress` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `role` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`managerid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1015 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of managerinfo
-- ----------------------------
INSERT INTO `managerinfo` VALUES (1001, '123', 'fh', '男', '372922199811227719', '1978-09-27', '科研处', '教授', '17865132531', '山东济南', 'D');
INSERT INTO `managerinfo` VALUES (1002, '123', '里斯', '女', '1111111111111', '2019-05-27', '教务处', '副教授', '22331312', '山东菏泽', 'D');
INSERT INTO `managerinfo` VALUES (1003, '123', '亚托克斯', '男', '12222222222', '2019-06-11', '教务处', '教授', '121334442', '山东青岛', 'D');
INSERT INTO `managerinfo` VALUES (1004, '1', 'Timor', '女', '112132432234', '2019-06-10', '教务处', '副教授', '1122434643', '山东淄博', 'D');
INSERT INTO `managerinfo` VALUES (1007, '123', '王舞', '女', '2324342523', '2019-06-17', '科研处', '教授', '21312324', '山东济南', 'D');
INSERT INTO `managerinfo` VALUES (1008, '123', '王玉', '女', '2324342523', '2019-06-17', '科研处', '教授', '21312324', '山东', 'D');
INSERT INTO `managerinfo` VALUES (1009, '123', '鱼', '男', '1124314', '2019-05-29', '科研处', '教授', '1231142', '北京', 'D');
INSERT INTO `managerinfo` VALUES (1010, '123', '鱼44r', '男', '1124314', '2019-05-29', '科研处', '教授', '1231142', '北京', 'D');
INSERT INTO `managerinfo` VALUES (1011, '123', '雨', '女', '1224', '2019-06-02', '科研处', '副教授', '22143254365', '上海', 'D');
INSERT INTO `managerinfo` VALUES (1012, '123', '李东', '男', '1321', '2019-05-26', '教务处', '教授', '12345', '广东', 'D');
INSERT INTO `managerinfo` VALUES (1013, '123', '零零', '男', '1234', '2019-05-26', '教务处', '副教授', '12231', '谷歌', 'D');
INSERT INTO `managerinfo` VALUES (1014, '123', '空客', '男', '1233', '2019-05-26', '科研处', '教授', '1324325', '山东', 'D');

-- ----------------------------
-- Table structure for selectcourse
-- ----------------------------
DROP TABLE IF EXISTS `selectcourse`;
CREATE TABLE `selectcourse`  (
  `selectid` int(20) NOT NULL AUTO_INCREMENT,
  `stuid` int(255) NULL DEFAULT NULL,
  `courname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `depart` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `teacherid` int(255) NULL DEFAULT NULL,
  `classdate` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `classplace` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`selectid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of selectcourse
-- ----------------------------
INSERT INTO `selectcourse` VALUES (1, 1001, '高等数学', '理工学院', 1001, NULL, NULL);
INSERT INTO `selectcourse` VALUES (3, 1001, '大学语文', '理工学院', 1001, NULL, NULL);
INSERT INTO `selectcourse` VALUES (4, 1001, '线性代数', '理工学院', 1001, NULL, NULL);
INSERT INTO `selectcourse` VALUES (5, 1001, '机器学习', 'AI 学院', 1003, NULL, NULL);

-- ----------------------------
-- Table structure for studentinfo
-- ----------------------------
DROP TABLE IF EXISTS `studentinfo`;
CREATE TABLE `studentinfo`  (
  `stuid` int(20) NOT NULL AUTO_INCREMENT,
  `stupassword` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `stuname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `sex` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `stuidcard` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `birthday` date NULL DEFAULT NULL,
  `studepartname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `stumajorname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `stulevel` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `stutel` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `stuaddress` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `role` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`stuid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1004 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of studentinfo
-- ----------------------------
INSERT INTO `studentinfo` VALUES (1001, '123', '阿卡丽', '女', '372922199811337712', '1978-11-22', '理工学院', '计算机科学与技术', '本科', '17865132531', '山东济南', 'B');
INSERT INTO `studentinfo` VALUES (1002, '123', '伊泽瑞尔', '男', '12314', '2019-06-30', '理工学院', '计算机科学', '研究生', '123214', '山东', 'B');

-- ----------------------------
-- Table structure for taskinfo
-- ----------------------------
DROP TABLE IF EXISTS `taskinfo`;
CREATE TABLE `taskinfo`  (
  `taskid` int(20) NOT NULL AUTO_INCREMENT,
  `taskcourname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `taskteaid` int(20) NULL DEFAULT NULL,
  `taskyear` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `taskteam` int(20) NULL DEFAULT NULL,
  `taskway` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `taskdepart` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `classdate` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `classplace` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`taskid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5008 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of taskinfo
-- ----------------------------
INSERT INTO `taskinfo` VALUES (5001, '线性代数', 1001, '2018-2019', 2, '闭卷', '理工学院', '周三（1，2节）', '1312');
INSERT INTO `taskinfo` VALUES (5002, '大学语文', 1001, '2019', 1, '开卷', '理工学院', '周一', '1312');
INSERT INTO `taskinfo` VALUES (5004, '高等数学', 1002, '2018-2019', 1, '闭卷', '理工学院', '周五全天', '1211');
INSERT INTO `taskinfo` VALUES (5005, '计算机网络', 1002, '2018-2019', 1, '闭卷', '理工学院', '周二（1，2节）', '1412');
INSERT INTO `taskinfo` VALUES (5006, '计算机组成原理', 1001, '2018-2019', 2, '闭卷', '理工学院', '周四下午', '1314');
INSERT INTO `taskinfo` VALUES (5007, '机器学习', 1003, '2019', 1, '开卷', 'AI 学院', '周六', '2313');

-- ----------------------------
-- Table structure for teacherinfo
-- ----------------------------
DROP TABLE IF EXISTS `teacherinfo`;
CREATE TABLE `teacherinfo`  (
  `teacherid` int(20) NOT NULL AUTO_INCREMENT,
  `teapassword` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `teachername` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `sex` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `teacheridcard` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `birthday` date NULL DEFAULT NULL,
  `teadepartname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `teamajorname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `teadegree` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `teaposition` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `teatel` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `teaaddress` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `role` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`teacherid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1004 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of teacherinfo
-- ----------------------------
INSERT INTO `teacherinfo` VALUES (1001, '123', '王永', '男', '1809', '1887-11-09', '理工学院', '计算机科学与技术', '博士', '教授', '17865378756', '山东济南', 'C');
INSERT INTO `teacherinfo` VALUES (1003, '132', '丽丝', '女', '1241', '2019-06-24', '理工学院', '计算机科学与技术', '博士', '教授', '13124124', '山东', 'C');

SET FOREIGN_KEY_CHECKS = 1;
